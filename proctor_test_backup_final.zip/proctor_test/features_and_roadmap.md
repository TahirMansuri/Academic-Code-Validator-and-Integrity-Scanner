# Features & Future Roadmap

This document outlines all the features currently implemented in the **Anti-Cheat Proctored MCQ Platform**, as well as planned future enhancements.

## ✅ Completed Features

### 1. Security & Proctoring Engine
- **Fullscreen Enforcement**: The browser automatically enters fullscreen mode when the test starts.
- **Webcam Monitoring**: A floating camera bubble with a flashing recording dot ensures students know they are being monitored.
- **Tab & Window Tracking**: The system detects `blur` and `visibilitychange` events if a student switches tabs or minimizes the window.
- **Screenshot Prevention**: Blocks right-click (context menu) and common keyboard shortcuts (Ctrl+C, Ctrl+V). Intercepts the `PrintScreen` key and overwrites the clipboard.
- **Three-Strike Rule**: A custom glassmorphism modal warns the student of violations. On the 3rd strike, the test auto-submits their current score with a penalty.

### 2. User Interface & Experience
- **Premium Aesthetics**: Utilizes a dynamic dark-mode gradient background with frosted glass (Glassmorphism) cards and smooth micro-animations.
- **Question Navigator**: A numbered sidebar grid allows students to jump to any specific question instantly.
- **Smart Status Colors**: 
  - **Unanswered**: Transparent outline.
  - **Passed (Skipped)**: Turns slate grey if the student clicks "Skip" or "Next" without answering.
  - **Answered**: Turns green.
- **Answer Locking**: Once a student selects an option, it is visually and functionally locked. They cannot change their answer.

### 3. Backend & Data
- **Firebase Firestore Integration**: Instantly pushes the final results (Student Name, Score, Total Possible Score, and Total Cheating Warnings) to a secure cloud database.
- **Progress Tracking**: A dynamic progress bar updates as the student completes the test.

---

## 🚀 Future Enhancements (Roadmap)

### 1. Dynamic Test Configuration
- **Randomization**: Shuffle the order of questions and multiple-choice options differently for every student so no two screens look exactly alike.
- **Cloud-Hosted Questions**: Fetch `questions.json` directly from the Firestore database instead of keeping it as a static local file.

### 2. Advanced Proctoring
- **Strict Timer Enforcement**: The current timer is visual. In the future, the test will automatically lock and submit when the timer hits `00:00`.
- **Cloud Video Recording**: Capture 5-second video snippets of the webcam feed at the exact moment a cheating violation occurs, and upload it to Firebase Storage for the teacher to review.
- **AI Eye Tracking**: Integrate a lightweight TensorFlow.js model to detect if the student is constantly looking off-screen at a hidden phone or monitor.

### 3. Admin Tools
- **Teacher Dashboard Page**: Build a secure `/admin.html` page where the instructor can log in and view a clean table of all student scores and violations without having to navigate the complex Firebase developer console.
