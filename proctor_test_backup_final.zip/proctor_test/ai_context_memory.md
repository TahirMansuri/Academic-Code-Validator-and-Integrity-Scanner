# AI Context Memory

This file serves as the memory state for the "Anti-Cheat Proctored MCQ Platform". When passing this project to another AI, provide this file to give it full context.

## Project Architecture
- **Directory**: `/proctor_test/`
- **Tech Stack**: HTML5, CSS3 (Glassmorphism design), Vanilla JavaScript, Firebase (Firestore & Hosting).
- **Purpose**: A strict online multiple-choice exam environment designed to prevent cheating on mobile and desktop.
- **Key Features**:
  - Enforces Fullscreen mode and requires Webcam access (floating recording bubble).
  - Tracks cheating via `window.blur` and `visibilitychange`. 3 violations = auto-submit and fail.
  - Blocks right-click, copy-paste, and intercepts `PrintScreen` to prevent screenshots.
  - **Question Navigator**: Dynamic sidebar grid where users can jump to any question.
  - **State Lock**: Once an option is clicked, it locks (users cannot change their answer). Skipped questions turn slate grey.
  - **Firebase Integration**: Saves `studentName`, `score`, `totalScore`, and `warnings` directly to a Firestore collection named `test_results`.
