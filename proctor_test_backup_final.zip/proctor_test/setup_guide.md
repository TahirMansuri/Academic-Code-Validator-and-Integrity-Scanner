# Complete Setup Guide

Follow this guide to set up and run the Proctor Test web application on a brand new laptop or machine.

## Prerequisites
1. Install **Node.js & npm** (required to install the Firebase tools).
2. Install **Git** to clone the repository.

---

## Setting up the Project

### 1. Clone the Project
```bash
git clone <your-github-repo-url>
cd ClassroomCode-Validator/proctor_test
```

### 2. Install Firebase CLI
In your terminal, install the Firebase tools globally so you can deploy to the cloud:
```bash
npm install -g firebase-tools
```

### 3. Authenticate Firebase
Log in to the Google Account that holds the Firebase project:
```bash
firebase login
```

### 4. Initialize & Deploy
Ensure you are inside the `proctor_test` directory.

If the project is already linked in your account, simply deploy it:
```bash
firebase deploy
```

If you need to link it to a completely new Firebase project:
1. Run `firebase use --add` and select your project from the list.
2. Run `firebase deploy` to publish the HTML, CSS, and JS files live to the internet.

### 5. Modifying Questions
To change the test questions, simply edit the `public/questions.json` file. Then run `firebase deploy` again to push the new questions live!
