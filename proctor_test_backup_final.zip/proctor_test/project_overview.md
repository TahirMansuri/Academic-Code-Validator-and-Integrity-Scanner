# Project Overview: Anti-Cheat Proctored MCQ Platform

## Creator Information
- **Author**: Tahir Husen Najir Mansuri
- **Profile**: Lead System Engineer at Optimas AI, H.O.D. & Asst. Prof. at IMRD Shahada, Java Full Stack Developer (9+ years experience).

## Why This Project Was Created
Conducting online exams is vulnerable to academic dishonesty (googling answers, taking screenshots, sharing questions). This project was built to conduct strictly monitored exams automatically, preventing cheating without requiring human proctors.

## Actual Use Cases & Capabilities
1. **Secure Environment**: Forces the browser into fullscreen and turns on the webcam to ensure the student is present.
2. **Cheating Detection**: Automatically catches students who switch tabs, minimize the browser, or attempt to take a screenshot.
3. **Automated Scoring**: Evaluates the MCQ answers instantly and pushes the final score to a secure Firebase cloud database.

## How to Use It
1. Provide the Firebase web app link (`https://proctor-test-mcq.web.app`) to students.
2. Students enter their name, accept camera permissions, and take the test.
3. The instructor monitors the results live in the Firebase Firestore Console under the `test_results` collection.
